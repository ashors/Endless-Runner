Anna Shors
ashors
Project 4
MW 10:25 Lab
I did not collaborate with anyone on this assignment.

====================================== DESCRIPTION ======================================

This project is a side-scrolling endless runner game, created using graphics and timers.

Special Instructions: 
Click mouse to jump.
Do not click mouse while character is still in the air.
Level 2 begins automatically about 20 seconds into the start of the game. This is the amount
of time it takes to successfully complete level 1.


====================================== HOW TO RUN =======================================

In Terminal (Mac) or Command Prompt (Windows),
cd ~/path/to/src
javac *.java
java [filename]